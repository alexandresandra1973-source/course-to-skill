#!/usr/bin/env python3
"""Confere o compromisso de cegamento do TEST-0008. Sem dependencias.

    python3 verify_blinding_commitment.py --nonce <hex> [--protocol BLINDING-PROTOCOL.yaml]

Recomputa o compromisso e a permutacao a partir do nonce revelado e do algoritmo
publicado ANTES da rodada. Qualquer pessoa pode rodar; nada aqui depende de
confiar em quem montou o pacote.
"""
import argparse, hashlib, itertools, re, sys

CANONICAL = sorted(["FULL_SKILL", "SUMMARY_AS_SKILL", "SUMMARY_AS_SUMMARY"])
PERMS = sorted(itertools.permutations(CANONICAL))


def derive(nonce: bytes):
    commit = hashlib.sha256(b"COMMIT|" + nonce).hexdigest()
    d = hashlib.sha256(b"DERIVE|" + nonce).digest()
    i = int.from_bytes(d[:8], "big") % len(PERMS)
    return commit, i, dict(zip(["A", "B", "C"], PERMS[i]))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--nonce", required=True)
    ap.add_argument("--protocol", default="BLINDING-PROTOCOL.yaml")
    a = ap.parse_args()
    commit, i, slots = derive(bytes.fromhex(a.nonce))
    print(f"commitment recomputado : {commit}")
    print(f"indice da permutacao   : {i} de {len(PERMS)}")
    for k, v in slots.items():
        print(f"  slot {k} = {v}")
    try:
        txt = open(a.protocol, encoding="utf-8").read()
        m = re.search(r"^commitment:\s*([0-9a-f]{64})", txt, re.M)
        if m:
            ok = m.group(1) == commit
            print(f"compromisso publicado  : {m.group(1)}")
            print(f"CONFERE                : {ok}")
            return 0 if ok else 1
        print("AVISO: nao achei `commitment:` no protocolo")
    except FileNotFoundError:
        print(f"AVISO: {a.protocol} nao encontrado; so recomputei")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
