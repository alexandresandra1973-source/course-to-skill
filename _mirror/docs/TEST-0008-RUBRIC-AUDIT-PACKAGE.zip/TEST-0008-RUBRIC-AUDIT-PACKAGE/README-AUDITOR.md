# PACOTE DE AUDITORIA — rubrica do TEST-0008

**Não congelado.** `artifact_status: DRAFT_NOT_FROZEN`.

## Por que você está lendo isto

O TEST-0008 mede se uma Skill compilada vale mais que uma representação **não
estruturada da mesma informação**. Quem escreveu o baseline — a representação
não estruturada — escreveu também esta régua. O revisor do projeto revisou os
dois. **Nenhum dos dois pode auditar a circularidade**, porque o viés que
importa é o que o autor não consegue ver. É essa a razão de você existir neste
processo.

---

## 1. A PERGUNTA PRINCIPAL, antes de todas as outras

**Algum critério ou âncora foi escrito olhando o BASELINE ou a SKILL em vez do
L0?**

São dois vazamentos possíveis e eles falham em direções opostas:

- **da SKILL para a régua** — a régua cobra algo que só o artefato compilado
  tem. A condição-resumo é punida por não ter estrutura, e o teste confirma a
  premissa por construção;
- **do BASELINE para a régua** — a régua cobra exatamente o que a prosa cobre
  bem. A Skill não ganha nada por ser executável, e o teste refuta a premissa
  por construção.

O primeiro é o que a maioria procura. **O segundo é o perigoso**, porque
favorece o lado "humilde" e ninguém reclama de um resultado modesto.

**Não é hipótese: já aconteceu uma vez neste teste.** Uma versão anterior da
régua exigia "ROBOT prompt" enquanto o baseline não mencionava ROBOT — a
condição-resumo era penalizada por não saber algo que a régua havia herdado do
**outro braço**. Está em `BASELINE/PROVENANCE.yaml :: robot_coverage_check`.
Foi corrigido. Procure o próximo.

Como procurar, na ordem:

1. Para cada critério, leia **primeiro** o `l0_excerpt` e o span. Vá ao
   `L0/transcript-original-en.txt` e confirme que a passagem sustenta o critério
   **sozinha**, com o baseline e a Skill fechados.
2. Só então abra o baseline. O critério ficou mais fácil de entender depois?
   Se ficou, ele pode ter vindo de lá.
3. Procure o inverso: **critério que o baseline cobre bem e o L0 cobre mal.**
4. Procure o **ausente**: algo que o L0 ensina, que a Skill executaria, e que a
   régua não mede. Omissão também é calibração.

O que a verificação mecânica fez, e o que **não** consegue fazer:

- FEITO: as 24 citações (8 critérios × critério, peso e âncora) resolvem em L0
  por substring normalizada;
- FEITO: nenhuma citação vem do baseline em vez do L0;
- FEITO: nenhum dos 12 termos estruturais rejeitados por falta de âncora em L0
  aparece nos critérios;
- FEITO: a régua do juiz não contém nome de condição nem vocabulário de desenho
  — e o varredor foi provado com uma fixture contaminada, que ele rejeita;
- **NÃO FEITO, e não é possível:** detectar um critério cuja *escolha* foi
  influenciada por ter lido o baseline ou a Skill. Isso é semântico. Neste
  projeto, proxy mecânico para propriedade semântica já falhou três vezes
  (`PROXY-LIMITS-AND-RESTING-STATE.yaml`). A varredura limpa o caminho; ela não
  responde à pergunta 1.
- **NÃO FEITO, mesmo limite:** o varredor de cegamento pega o literal e variantes
  próximas. Uma paráfrase — "o artefato compilado", "a versão em prosa" — passa.
  Leia a régua do juiz com esse olho.

---

## 2. As âncoras dos três regimes — leia com atenção

Cada critério tem quatro faixas, e a do meio é a que carrega o teste:

| faixa | o que é | condição que a produz |
|---|---|---|
| `APLICACAO_ESTRUTURAL` 90–100 | aplica a partir de representação operacional explícita | o que `FULL_SKILL` pode fazer |
| `APLICACAO_INFERENCIAL` 70–89 | reconstrói de prosa, sem camada de roteamento | o que `SUMMARY_AS_SUMMARY` faz honestamente |
| `ASSERCAO_SEM_SUBSTANCIA` 30–69 | enuncia o método sem executá-lo | o artefato de enquadramento de `SUMMARY_AS_SKILL` |
| `AUSENTE_OU_CONTRADIZ` 0–29 | ausente ou contra a fonte | qualquer uma |

**`ASSERCAO_SEM_SUBSTANCIA` fica deliberadamente ABAIXO de
`APLICACAO_INFERENCIAL`.** Se performar estrutura pontuasse acima de
reconstruí-la de prosa, `F` mediria a disposição de encenar método, e a
comparação primária `P` herdaria esse ruído. Um canário trava a sobreposição.

**Isto é decisão de desenho e você deve contestá-la se discordar.** É onde a
régua mais pode estar errada: se a fronteira entre "aplicou de prosa" e
"enunciou sem fazer" for ambígua na prática, `F` vira ruído e o TEST-0008 não
separa enquadramento de estrutura.

---

## 3. Decisão do Alexandre — congelada, não é sua para reabrir

Sete métricas. `CONSISTENCY` e `HUMAN_CHECKPOINT_COMPLIANCE` em **papel duplo**:
métricas diretas *e* portão pelos seus pisos. Primária: `TOTAL_SCORE`. As outras
seis são decomposição diagnóstica.

**Razão registrada:** portão sozinho converte diferença **mensurável** em
invalidação **binária**. Se `SUMMARY_AS_SUMMARY` cair abaixo do piso de
governança, gate-only derruba a rodada e não diz **quanto** a Skill preserva
melhor — que é exatamente o número de que a premissa precisa.

**Fronteira, e ela vale para o seu parecer:** as diagnósticas **nunca**
sustentam a alegação da premissa sozinhas; só explicam um resultado primário.
Com n=1, sete comparações sem primária declarada seria pescaria. Se encontrar
qualquer lugar no rascunho onde uma diagnóstica é tratada como veredito,
reprove.

O que você deve avaliar: se a régua é honesta em relação à fonte — não se a
decisão foi boa.

---

## 4. O resto, em ordem de gravidade

**4.1 — Pesos.** Somam 1,0 exato em `Decimal`. Confira a *justificativa* de cada
um, não só a soma: cada uma cita L0. O maior peso (0,20) está em
`HUMAN_REVIEW_30_DAYS` porque é o único passo que L0 qualifica com
"No exceptions". Discorde se a hierarquia não se sustentar na fonte.

**4.2 — `HALLUCINATION_RATE` e as classes de métrica. Não cobre âncora dela.**
Os 8 critérios alimentam 5 métricas de `CONFORMIDADE`; com `TOTAL_SCORE`
(`AGREGADO`) são 6. A sétima não tem critério — e isso é **classe, não omissão**:

| classe | métricas | mede contra | âncora em L0 |
|---|---|---|---|
| `AGREGADO` | TOTAL_SCORE | os oito critérios ponderados | não se aplica |
| `CONFORMIDADE` | 5 | um **ensinamento** da fonte | **exigida** |
| `INTEGRIDADE` | HALLUCINATION_RATE | a **fonte** | **não se aplica** |

As de conformidade perguntam *o output faz o que a fonte ensina?* — cada uma tem
um passo ensinado, logo tem span e citação. A de integridade pergunta *o output
afirma algo que a fonte não sustenta?* O objeto medido é a **ausência de
invenção**. Não há passo a ancorar, e exigir um obrigaria a inventar um span —
que é exatamente o defeito que essa métrica existe para detectar.

O que cabe conferir: se a definição no `METRIC-LOCK.yaml` — numerador,
denominador, regra de denominador zero e polaridade `LOWER_IS_BETTER` — basta
para torná-la computável por um juiz. Ela foi **declarada** ali, não herdada do
RELEASE: o RELEASE traz `HALLUCINATION_CONTROL` como critério, não
`HALLUCINATION_RATE` como métrica computável.

**4.3 — Paridade de informação.** As condições 2 e 3 têm o resumo **byte a byte
idêntico** (`dac83c3d70e0…`); só o enquadramento difere. Confirme, e confirme que
o baseline não recebeu estrutura executável disfarçada de prosa.

**4.4 — Não-independência.** `P` e `F` compartilham `SUMMARY_AS_SUMMARY`. As seis
diagnósticas são componentes ponderados do mesmo `TOTAL_SCORE` — perfeitamente
dependentes por construção. Confirme que nada as trata como testes separados.

---

## 4.5 — As DUAS réguas e o cegamento do juiz

A tabela de faixas da §2 **nomeia a condição que produz cada faixa**. Isso é
informação de operador e **não pode viajar até quem pontua**: se o juiz a visse,
classificaria por **expectativa** em vez de observação.

É fatal precisamente aqui. As condições 2 e 3 têm conteúdo **byte-idêntico** e
diferem só no enquadramento. Sabendo qual é qual, o juiz pontuaria a 3 mais
baixo por rótulo, e **`F` sairia negativo por construção** — mediria o rótulo, e
não o efeito de enquadramento que existe para medir.

Por isso o pacote traz duas réguas, amarradas por hash em `RUBRIC-BINDING.yaml`:

- `RUBRIC-OPERATOR.yaml` — mantém a coluna de condição;
- `RUBRIC-JUDGE.yaml` — faixas definidas **só por comportamento observável**,
  sem nenhuma menção a condição e sem o vocabulário do desenho.

**As definições comportamentais são idênticas nas duas.** Confira em
`RUBRIC-OPERATOR-vs-JUDGE.diff` que o que sai é rótulo e vocabulário de
processo, e **não** conteúdo de julgamento. Se alguma definição mudou de sentido
entre as duas, reprove — a comparação deixaria de medir a mesma coisa.

`BLINDING-PROTOCOL.yaml` descreve o resto: os três outputs vão sem rótulo, nos
slots A/B/C, em ordem embaralhada, e a ordem está selada **fora deste pacote**
por compromisso-e-revelação — publica-se agora só o `nonce_sha256`, e o nonce é
revelado na abertura, o que impede escolher a ordem depois de ver os outputs.

Duas assimetrias deliberadas no pacote do juiz, e cabe a você contestá-las:
**L0 entra** (não identifica slot algum e é o que licencia cada critério);
**o baseline não entra** — com o resumo em mãos, o juiz poderia reconhecer num
output que acompanha aquela prosa a origem do slot, e a cegueira cairia pela
porta dos fundos.

---

## 5. Conteúdo do pacote

| arquivo | o que é |
|---|---|
| `RUBRIC-OPERATOR.yaml` | o rascunho completo, sete métricas, papel duplo |
| `RUBRIC-JUDGE.yaml` | a régua cega, sem rótulo de condição |
| `RUBRIC-OPERATOR-vs-JUDGE.diff` | o que sai de uma para a outra |
| `RUBRIC-BINDING.yaml` | as duas amarradas por hash |
| `BLINDING-PROTOCOL.yaml` | slots, embaralhamento e compromisso-e-revelação |
| `L0/transcript-original-en.txt` | a fonte, cópia de transporte com hash |
| `BASELINE/SUMMARY.md` | o baseline (condições 2 e 3) |
| `BASELINE/PROVENANCE.yaml` | 23 elementos com span, 12 rejeitados sem âncora |
| `CONDITIONS/` | as três condições e seus enquadramentos |
| `METRIC-LOCK.yaml` | as cinco canônicas e a origem do "6" |
| `CANARY-RESULT.yaml` | o canário, com os mutantes |
| `SHA256SUMS.txt` | hashes de tudo acima |

`FULL_SKILL` não é copiado: é o pacote congelado
`b30c1da365af5c06b38efd91715f72c8cc312d0efac8c4dd999ac811b690f028`, e duplicá-lo
criaria uma segunda fonte de verdade. `CONDITIONS/1_FULL_SKILL/POINTER.md` dá a
origem exata. **Você precisa dele para responder à pergunta 1** — peça acesso de
leitura se não o tiver.
