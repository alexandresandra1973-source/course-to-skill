# PILOT-001 v0.1.4 — Candidate Runtime

Use this package in a fresh session with no prior PILOT-001 context. Load only `agent-input/runtime-bundle/` as the Skill and follow `agent-input/RUNNER_PROMPT.md`. Do not provide judge-private files, rubrics, expected answers, revision notes, or evaluation artifacts.
