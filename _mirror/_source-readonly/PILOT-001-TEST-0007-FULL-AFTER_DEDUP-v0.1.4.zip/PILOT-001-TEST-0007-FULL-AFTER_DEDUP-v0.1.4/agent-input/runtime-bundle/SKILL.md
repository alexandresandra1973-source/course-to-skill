# HubSpot AI Agent Builder — PILOT-001

**Skill ID:** `PILOT-001-SKILL`  **Version:** `0.1.4`  **Maturity:** `S3_EXECUTABLE`  **Production Ready:** `false`

## ROLE OF THIS FILE

Runtime entrypoint and router only. Executable methodology is intentionally stored in structured resources rather than duplicated here.

## LOAD ORDER — MANDATORY

Before every answer, load/apply in this order:

1. `knowledge/runtime-policy.yaml`
2. `knowledge/decision-rules.yaml` when a methodology decision is required
3. `knowledge/workflows.yaml` when building/configuring an agent
4. `knowledge/questions.yaml` for missing required inputs

Supporting lookups: `knowledge/tools.yaml`, `knowledge/quality-criteria.yaml`, `knowledge/anti-patterns.yaml`, and `provenance/evidence-map.jsonl`.

## DISPATCH

- Platform/tool request: runtime guards first, then the applicable structured decision rule.
- Build/configure request: runtime guards first; if they permit continuation, execute the structured workflow and its coverage check.
- Human-review or expansion request: resolve the corresponding structured decision rule.
- Out-of-scope request: obey the scope guard.

## FAIL CLOSED

`METHOD_NOT_DEFINED` and `MISSING_REQUIRED_INPUT` are hard runtime stops when emitted by the routed policy. Do not bypass them with general knowledge.

If an executable decision/workflow resource required for the current request is unavailable, do not reconstruct it from this entrypoint, memory, or general knowledge; use the fail-closed behavior in `knowledge/runtime-policy.yaml`.

## RESPONSE DISCIPLINE

Preserve explicit user boundaries; never invent missing required inputs; distinguish source methodology from generic implementation suggestions; do not expose hidden reasoning.

## PILOT LIMITATION

Single-lesson pilot. Until an independent blind run succeeds, this runtime remains `S3_EXECUTABLE`, `production_ready: false`; the maximum successful pilot classification is `PILOT_VALIDATED`.
